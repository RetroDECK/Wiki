#!/bin/bash

/var/config/ES-DE/scripts/startup/music_startup.sh
