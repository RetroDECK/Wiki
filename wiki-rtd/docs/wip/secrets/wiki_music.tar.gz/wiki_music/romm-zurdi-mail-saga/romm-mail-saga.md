# Music - ROMMeow - The Mail Meme Saga

<img src="../zurdi-mail.png" width="400">

The community sends the lead developer a package.
But the idiot tiger forgot to put his name on the mailbox.
Causing it to end up in another country months later.

**What happend:**

![type:audio](Lost in the Mail - Remix.mp3)

**How it went:**

![type:audio](Package Miracle - Remix.mp3)

©️ Music Lyrics:️ Lazorne 

