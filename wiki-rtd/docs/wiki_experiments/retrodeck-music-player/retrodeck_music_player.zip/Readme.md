# RetroDECK Background Music
This script was created by Discord user Partack, from an idea of TopHatCat and itś revised by Xargon.

## Setup
- Copy all provided files into ~/.var/app/net.retrodeck.retrodeck/config/ES-DE/scripts/
- run `chmod +x ~/.var/app/net.retrodeck.retrodeck/config/ES-DE/scripts/**/*.sh` to ensure the scripts got the right permissions
- open `RetroDECK`, open `ES-DE Main Menu` and enable the custom scripts into `ES-DE Settings` -> `Other Settings` -> `Enable Custom Scripts`
- quit `RetroDECK`
- Place your music files into the `retrodeck/music` folder, if the folder is not existing, open `RetroDECK` once again or manually create it.

The script supports `.mp3`, `.ogg`, `.flac` and `.wav` music files.

## Additional options

There are some options in the `music_startup.sh` script (in the startup folder)
they're at the top of the script, should be pretty self-explanatory:

MUSIC_DIR="$rdhome/music"
CROSSFADE=true          # true or false
CROSSFADE_DURATION=2    # in seconds
VOLUME=0.2              # from 0.0 to 1.0

## Uninstalling the script
- remove the contents of `~/.var/app/net.retrodeck.retrodeck/config/ES-DE/scripts` folder
- optionally, disable the custom script: open `RetroDECK`, open `ES-DE Main Menu` and disable the custom scripts into `ES-DE Settings` -> `Other Settings` -> `Enable Custom Scripts`
- optionally, remove `retrodeck/music` folder
