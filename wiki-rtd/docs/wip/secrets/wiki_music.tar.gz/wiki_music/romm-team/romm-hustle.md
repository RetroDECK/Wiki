# Music - ROMMeow - Team Hustle Meeting

<img src="../romm-team.png" width="600">

```
Zurdi: 

Ok everyone, the Purrfect Team Meeting is on!

*puts down his server rack*. 

The RetroDECK Team is getting too powerful. 
We don't know what will happen next.
All I know is we to get into van ASAP! 
Then we go straight gangsta on their sloth asses. 
ROMM Team Roll Out!
```

![type:audio](ROMM Hustling.mp3)

©️ Music Lyrics:️ Lazorne 
