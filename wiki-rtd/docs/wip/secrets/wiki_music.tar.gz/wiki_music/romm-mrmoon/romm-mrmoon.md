# Music - ROMMeow - The Tears of Mr.Moon

See what you did, you made Mr.Moon sad! :(

<img src="../romm-mrmoon-sad-plush.png" width="300">

![type:audio](The Tears of Mr.Moon - Remix.mp3)

©️ Music Lyrics:️ Lazorne 
