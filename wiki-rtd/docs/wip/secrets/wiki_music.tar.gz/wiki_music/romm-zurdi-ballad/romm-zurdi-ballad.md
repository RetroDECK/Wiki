# Music - ROMMeow - The Ballad of Zurdi

<img src="../zurdi-coder-cheese.png" width="200">

![type:audio](The Ballad of Zurdi.mp3)

©️ Music Lyrics:️ Lazorne 
