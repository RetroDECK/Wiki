# Music - RD - Just don't do it!

<img src="../sloth-cabin.png" width="600">

![type:audio](Don't do it.mp3)

©️ Music Lyrics:️ Lazorne 
