# Music - MUOS Jingle

<img src="../muos-opossum.png" width="300">

```
These sloths should know we are opossums not cows. 

MUOS is for handheld devices (and opossums).
```

![type:audio](MUOS Jingle.mp3)

©️ Music Lyrics:️ Lazorne 
