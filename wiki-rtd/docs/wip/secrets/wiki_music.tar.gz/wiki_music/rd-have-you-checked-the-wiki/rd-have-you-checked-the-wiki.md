# Music -  Have you checked the Wiki?

<img src="../user-happy.png" width="300">

![type:audio](Have you checked the wiki.mp3)

©️ Music Lyrics:️ Lazorne 
