# Music - What will happen to RetroDECK?

<img src="../thalin-the-troll.png"  width="300">


![type:audio](What will Happen to RetroDECK - Remastered.mp3)


©️ Music Lyrics: Lazorne the Troll Hunter (┛ಠ_ಠ)┛彡┻━┻   ©️ Art: Thalin the Troll
